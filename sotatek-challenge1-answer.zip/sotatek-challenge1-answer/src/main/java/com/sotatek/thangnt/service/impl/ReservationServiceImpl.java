package com.sotatek.thangnt.service.impl;

import com.sotatek.thangnt.dto.request.CreateReservationRequest;
import com.sotatek.thangnt.dto.request.ReservationItemRequest;
import com.sotatek.thangnt.dto.response.ReservationResponse;
import com.sotatek.thangnt.entity.Inventory;
import com.sotatek.thangnt.entity.Reservation;
import com.sotatek.thangnt.entity.ReservationItem;
import com.sotatek.thangnt.exception.InsufficientStockException;
import com.sotatek.thangnt.exception.InventoryNotFoundException;
import com.sotatek.thangnt.exception.ReservationNotFoundException;
import com.sotatek.thangnt.factory.ReservationFactory;
import com.sotatek.thangnt.mapper.ReservationMapper;
import com.sotatek.thangnt.repository.InventoryRepository;
import com.sotatek.thangnt.repository.ReservationRepository;
import com.sotatek.thangnt.service.ReservationService;
import com.sotatek.thangnt.state.ReservationState;
import com.sotatek.thangnt.factory.ReservationStateFactory;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ReservationServiceImpl implements ReservationService {

    private final ReservationRepository reservationRepository;

    private final InventoryRepository inventoryRepository;

    private final ReservationFactory reservationFactory;

    private final ReservationMapper reservationMapper;

    private final ReservationStateFactory stateFactory;

    @Override
    @Transactional
    public ReservationResponse reserve(CreateReservationRequest request) {

        Map<String, Integer> requestedBySku =
                request
                        .getItems()
                        .stream()
                        .collect(Collectors.groupingBy(ReservationItemRequest::getSku,
                                Collectors.summingInt(ReservationItemRequest::getQuantity)));

        Map<String, Inventory> inventoryMap = new HashMap<>();


        for (Map.Entry<String, Integer> entry : requestedBySku.entrySet()) {

            String sku = entry.getKey();
            Integer requestedQuantity = entry.getValue();

            Inventory inventory = inventoryRepository
                    .findBySkuForUpdate(sku)
                    .orElseThrow(() -> new InventoryNotFoundException(sku));

            if (!inventory.canReserve(requestedQuantity)) {
                throw new InsufficientStockException(sku, inventory.getAvailableStock(), requestedQuantity);
            }

            inventoryMap.put(sku, inventory);
        }

        for (Map.Entry<String, Integer> entry : requestedBySku.entrySet()) {

            Inventory inventory = inventoryMap.get(entry.getKey());
            inventory.reserve(entry.getValue());
        }


        Reservation reservation = reservationFactory.create(request.getOrderId(), new ArrayList<>());

        List<ReservationItem> reservationItems = request.getItems().stream().map(item -> {

            ReservationItem reservationItem = new ReservationItem();

            reservationItem.setReservation(reservation);

            reservationItem.setSku(item.getSku());

            reservationItem.setQuantity(item.getQuantity());

            return reservationItem;
        }).toList();

        reservation.setItems(reservationItems);

        Reservation savedReservation = reservationRepository.save(reservation);

        return reservationMapper.toResponse(savedReservation);
    }

    @Override
    @Transactional
    public ReservationResponse confirm(Long reservationId) {
        Reservation reservation = reservationRepository
                .findById(reservationId)
                .orElseThrow(() -> new ReservationNotFoundException(reservationId));

        ReservationState state = stateFactory.getState(reservation.getStatus());
        state.confirm(reservation);
        reservationRepository.save(reservation);
        return reservationMapper.toResponse(reservation);
    }

    @Override
    @Transactional
    public ReservationResponse cancel(Long reservationId) {

        Reservation reservation = reservationRepository
                .findById(reservationId)
                .orElseThrow(() -> new ReservationNotFoundException(reservationId));

        ReservationState state = stateFactory.getState(reservation.getStatus());
        state.cancel(reservation);

        for (ReservationItem item : reservation.getItems()) {
            Inventory inventory = inventoryRepository
                    .findBySkuForUpdate(item.getSku())
                    .orElseThrow(() -> new InventoryNotFoundException(item.getSku()));
            inventory.release(item.getQuantity());
        }
        reservationRepository.save(reservation);
        return reservationMapper.toResponse(reservation);
    }

    @Override
    public ReservationResponse getById(Long reservationId) {
        Reservation reservation = reservationRepository.findById(reservationId).orElseThrow(() -> new ReservationNotFoundException(reservationId));
        return reservationMapper.toResponse(reservation);
    }
}
