package com.sotatek.thangnt.service.impl;

import com.sotatek.thangnt.dto.response.InventoryResponse;
import com.sotatek.thangnt.exception.InventoryNotFoundException;
import com.sotatek.thangnt.mapper.InventoryMapper;
import com.sotatek.thangnt.repository.InventoryRepository;
import com.sotatek.thangnt.service.InventoryService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class InventoryServiceImpl implements InventoryService {

    private final InventoryRepository inventoryRepository;

    private final InventoryMapper inventoryMapper;

    @Override
    @Transactional
    public InventoryResponse getBySku(String sku) {
        return inventoryRepository.findBySku(sku)
                .map(inventoryMapper::toResponse)
                .orElseThrow(() -> new InventoryNotFoundException(sku));
    }
}