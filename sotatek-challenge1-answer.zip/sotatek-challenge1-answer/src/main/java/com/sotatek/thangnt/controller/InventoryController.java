package com.sotatek.thangnt.controller;

import com.sotatek.thangnt.dto.response.ApiResponse;
import com.sotatek.thangnt.dto.response.InventoryResponse;
import com.sotatek.thangnt.service.InventoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/inventory")
@RequiredArgsConstructor
public class InventoryController {

    private final InventoryService inventoryService;

    @GetMapping("/{sku}")
    public ApiResponse<InventoryResponse> getInventory(@PathVariable String sku) {
        InventoryResponse response = inventoryService.getBySku(sku);
        return ApiResponse.<InventoryResponse>builder()
                .success(true)
                .data(response)
                .message("getInventory success")
                .build();
    }
}