package com.sotatek.thangnt.controller;

import com.sotatek.thangnt.dto.response.InventoryResponse;
import com.sotatek.thangnt.entity.Inventory;
import com.sotatek.thangnt.exception.InventoryNotFoundException;
import com.sotatek.thangnt.mapper.InventoryMapper;
import com.sotatek.thangnt.repository.InventoryRepository;
import com.sotatek.thangnt.service.impl.InventoryServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class InventoryServiceImplTest {

    @Mock
    private InventoryRepository inventoryRepository;

    @Mock
    private InventoryMapper inventoryMapper;

    @InjectMocks
    private InventoryServiceImpl inventoryService;

    @Test
    void getBySku_success() {

        String sku = "A100";

        Inventory inventory = Inventory.builder()
                .sku(sku)
                .totalStock(100)
                .availableStock(80)
                .reservedStock(20)
                .build();

        InventoryResponse response = InventoryResponse.builder()
                .sku(sku)
                .totalStock(100)
                .availableStock(80)
                .reservedStock(20)
                .build();

        when(inventoryRepository.findBySku(sku))
                .thenReturn(Optional.of(inventory));

        when(inventoryMapper.toResponse(inventory))
                .thenReturn(response);

        InventoryResponse result =
                inventoryService.getBySku(sku);

        assertNotNull(result);
        assertEquals("A100", result.getSku());
        assertEquals(100, result.getTotalStock());
        assertEquals(80, result.getAvailableStock());
        assertEquals(20, result.getReservedStock());

        verify(inventoryRepository)
                .findBySku(sku);

        verify(inventoryMapper)
                .toResponse(inventory);
    }

    @Test
    void getBySku_shouldThrowInventoryNotFoundException() {

        String sku = "A100";

        when(inventoryRepository.findBySku(sku))
                .thenReturn(Optional.empty());

        InventoryNotFoundException ex =
                assertThrows(
                        InventoryNotFoundException.class,
                        () -> inventoryService.getBySku(sku)
                );

        assertEquals(
                "Inventory not found for sku A100",
                ex.getMessage()
        );

        verify(inventoryRepository)
                .findBySku(sku);

        verifyNoInteractions(inventoryMapper);
    }
}