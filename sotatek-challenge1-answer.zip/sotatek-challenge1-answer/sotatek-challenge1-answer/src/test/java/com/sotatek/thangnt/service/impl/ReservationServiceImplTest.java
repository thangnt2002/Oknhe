package com.sotatek.thangnt.service.impl;

import com.sotatek.thangnt.dto.request.CreateReservationRequest;
import com.sotatek.thangnt.dto.request.ReservationItemRequest;
import com.sotatek.thangnt.dto.response.ReservationResponse;
import com.sotatek.thangnt.entity.Inventory;
import com.sotatek.thangnt.entity.Reservation;
import com.sotatek.thangnt.entity.ReservationItem;
import com.sotatek.thangnt.enums.ReservationStatus;
import com.sotatek.thangnt.exception.InsufficientStockException;
import com.sotatek.thangnt.exception.InvalidReservationStateException;
import com.sotatek.thangnt.exception.InventoryNotFoundException;
import com.sotatek.thangnt.exception.ReservationNotFoundException;
import com.sotatek.thangnt.factory.ReservationFactory;
import com.sotatek.thangnt.factory.ReservationStateFactory;
import com.sotatek.thangnt.mapper.ReservationMapper;
import com.sotatek.thangnt.repository.InventoryRepository;
import com.sotatek.thangnt.repository.ReservationRepository;
import com.sotatek.thangnt.state.CancelledState;
import com.sotatek.thangnt.state.ConfirmedState;
import com.sotatek.thangnt.state.PendingState;
import com.sotatek.thangnt.state.ReservationState;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ReservationServiceImplTest {

    @Mock
    private ReservationRepository reservationRepository;

    @Mock
    private InventoryRepository inventoryRepository;

    @Mock
    private ReservationMapper reservationMapper;

    @Mock
    private ReservationFactory reservationFactory;

    @InjectMocks
    private ReservationServiceImpl reservationService;

    @Mock
    private ReservationStateFactory stateFactory;

    @Mock
    private ReservationState reservationState;

    @Test
    void reserve_success() {

        CreateReservationRequest request = new CreateReservationRequest("ORD-1001", List.of(new ReservationItemRequest("A100", 5)));

        Inventory inventory = Inventory
                .builder()
                .sku("A100")
                .totalStock(100)
                .availableStock(100)
                .reservedStock(0)
                .build();

        Reservation reservation = Reservation
                .builder()
                .id(1L)
                .items(new ArrayList<>())
                .build();

        ReservationResponse response = ReservationResponse
                .builder()
                .id(1L)
                .orderId("ORD-1001")
                .build();

        when(inventoryRepository.findBySkuForUpdate("A100")).thenReturn(Optional.of(inventory));

        when(reservationFactory.create(eq("ORD-1001"), anyList())).thenReturn(reservation);

        when(reservationRepository.save(any(Reservation.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        when(reservationMapper.toResponse(any(Reservation.class)))
                .thenReturn(response);

        ReservationResponse result = reservationService.reserve(request);

        assertNotNull(result);
        assertEquals(1L, result.getId());

        assertEquals(95, inventory.getAvailableStock());
        assertEquals(5, inventory.getReservedStock());

        verify(reservationRepository).save(any(Reservation.class));
    }

    @Test
    void reserve_shouldThrowInventoryNotFoundException() {

        CreateReservationRequest request =
                new CreateReservationRequest("ORD-1001", List.of(new ReservationItemRequest("A100", 5)));

        when(inventoryRepository.findBySkuForUpdate("A100")).thenReturn(Optional.empty());

        assertThrows(InventoryNotFoundException.class, () -> reservationService.reserve(request));

        verify(reservationRepository, never()).save(any());
    }

    @Test
    void reserve_shouldThrowInsufficientStockException() {

        CreateReservationRequest request =
                new CreateReservationRequest("ORD-1001", List.of(new ReservationItemRequest("A100", 150)));

        Inventory inventory = Inventory
                .builder()
                .sku("A100")
                .totalStock(100)
                .availableStock(100)
                .reservedStock(0)
                .build();

        when(inventoryRepository.findBySkuForUpdate("A100")).thenReturn(Optional.of(inventory));

        assertThrows(InsufficientStockException.class, () -> reservationService.reserve(request));

        verify(reservationRepository, never()).save(any());
    }

    @Test
    void confirm_success() {

        Reservation reservation = Reservation
                .builder().id(1L).status(ReservationStatus.PENDING).build();

        ReservationResponse response = ReservationResponse
                .builder()
                .id(1L)
                .status(ReservationStatus.CONFIRMED.name())
                .build();

        when(reservationRepository
                .findById(1L))
                .thenReturn(Optional.of(reservation));

        when(stateFactory
                .getState(ReservationStatus.PENDING))
                .thenReturn(reservationState);

        when(reservationRepository.save(any(Reservation.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        when(reservationMapper.toResponse(any(Reservation.class))).thenReturn(response);

        ReservationResponse result = reservationService.confirm(1L);

        verify(stateFactory).getState(ReservationStatus.PENDING);

        verify(reservationState).confirm(reservation);

        verify(reservationRepository).save(reservation);

        assertNotNull(result);
    }

    @Test
    void confirm_shouldThrowReservationNotFoundException() {

        when(reservationRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(ReservationNotFoundException.class, () -> reservationService.confirm(1L));

        verify(reservationRepository, never()).save(any());
    }

    @Test
    void cancel_success() {

        Inventory inventory = Inventory.builder().sku("A100").availableStock(70).reservedStock(30).build();

        ReservationItem item = ReservationItem
                .builder().sku("A100").quantity(30).build();

        Reservation reservation = Reservation
                .builder().id(1L).status(ReservationStatus.PENDING).items(List.of(item)).build();

        ReservationResponse response = ReservationResponse
                .builder().id(1L).status(ReservationStatus.CANCELLED.name()).build();

        when(reservationRepository.findById(1L))
                .thenReturn(Optional.of(reservation));

        when(stateFactory.getState(ReservationStatus.PENDING)).thenReturn(reservationState);

        when(inventoryRepository.findBySkuForUpdate("A100")).thenReturn(Optional.of(inventory));

        when(reservationRepository.save(any(Reservation.class))).thenAnswer(invocation -> invocation.getArgument(0));

        when(reservationMapper.toResponse(any(Reservation.class))).thenReturn(response);

        ReservationResponse result = reservationService.cancel(1L);

        verify(reservationState).cancel(reservation);

        verify(inventoryRepository).findBySkuForUpdate("A100");

        verify(reservationRepository).save(reservation);

        assertNotNull(result);
    }

    @Test
    void cancel_shouldThrowInventoryNotFoundException() {

        ReservationItem item = ReservationItem
                .builder().sku("A100").quantity(10).build();

        Reservation reservation = Reservation
                .builder().status(ReservationStatus.PENDING).items(List.of(item)).build();

        when(reservationRepository.findById(1L)).thenReturn(Optional.of(reservation));

        when(stateFactory.getState(ReservationStatus.PENDING)).thenReturn(reservationState);

        when(inventoryRepository.findBySkuForUpdate("A100")).thenReturn(Optional.empty());

        assertThrows(InventoryNotFoundException.class, () -> reservationService.cancel(1L));
    }

    @Test
    void confirmedState_confirm_shouldThrowException() {

        Reservation reservation = Reservation.builder()
                .status(ReservationStatus.CONFIRMED)
                .build();

        ConfirmedState state = new ConfirmedState();

        InvalidReservationStateException ex =
                assertThrows(
                        InvalidReservationStateException.class,
                        () -> state.confirm(reservation)
                );

        assertEquals(
                "Reservation already confirmed",
                ex.getMessage()
        );
    }

    @Test
    void confirmedState_cancel_shouldThrowException() {

        Reservation reservation = Reservation.builder()
                .status(ReservationStatus.CONFIRMED)
                .build();

        ConfirmedState state = new ConfirmedState();

        InvalidReservationStateException ex =
                assertThrows(
                        InvalidReservationStateException.class,
                        () -> state.cancel(reservation)
                );

        assertEquals(
                "Confirmed reservation cannot be cancelled",
                ex.getMessage()
        );
    }

    @Test
    void cancelledState_confirm_shouldThrowException() {

        Reservation reservation = Reservation.builder()
                .status(ReservationStatus.CANCELLED)
                .build();

        CancelledState state = new CancelledState();

        InvalidReservationStateException ex =
                assertThrows(
                        InvalidReservationStateException.class,
                        () -> state.confirm(reservation)
                );

        assertEquals(
                "Cancelled reservation cannot be confirmed",
                ex.getMessage()
        );
    }

    @Test
    void cancelledState_cancel_shouldThrowException() {

        Reservation reservation = Reservation.builder()
                .status(ReservationStatus.CANCELLED)
                .build();

        CancelledState state = new CancelledState();

        InvalidReservationStateException ex =
                assertThrows(
                        InvalidReservationStateException.class,
                        () -> state.cancel(reservation)
                );

        assertEquals(
                "Reservation already cancelled",
                ex.getMessage()
        );
    }

    @Test
    void pendingState_confirm_shouldMoveToConfirmed() {

        Reservation reservation = Reservation.builder()
                .status(ReservationStatus.PENDING)
                .build();

        PendingState state = new PendingState();

        state.confirm(reservation);

        assertEquals(
                ReservationStatus.CONFIRMED,
                reservation.getStatus()
        );
    }

    @Test
    void pendingState_cancel_shouldMoveToCancelled() {

        Reservation reservation = Reservation.builder()
                .status(ReservationStatus.PENDING)
                .build();

        PendingState state = new PendingState();

        state.cancel(reservation);

        assertEquals(
                ReservationStatus.CANCELLED,
                reservation.getStatus()
        );
    }
}