CREATE TABLE products
(
    id          BIGSERIAL PRIMARY KEY,
    sku         VARCHAR(50)  NOT NULL UNIQUE,
    name        VARCHAR(255) NOT NULL,
    description VARCHAR(500)
);

CREATE TABLE inventory
(
    id              BIGSERIAL PRIMARY KEY,
    sku             VARCHAR(50) NOT NULL UNIQUE,
    total_stock     INT         NOT NULL,
    available_stock INT         NOT NULL,
    reserved_stock  INT         NOT NULL
);

CREATE TABLE reservations
(
    id         BIGSERIAL PRIMARY KEY,
    order_id   VARCHAR(100) NOT NULL,
    status     VARCHAR(50)  NOT NULL,
    created_at TIMESTAMP    NOT NULL
);

CREATE TABLE reservation_items
(
    id             BIGSERIAL PRIMARY KEY,
    reservation_id BIGINT      NOT NULL,
    sku            VARCHAR(50) NOT NULL,
    quantity       INT         NOT NULL,

    CONSTRAINT fk_reservation_item_reservation
        FOREIGN KEY (reservation_id)
            REFERENCES reservations (id)
);