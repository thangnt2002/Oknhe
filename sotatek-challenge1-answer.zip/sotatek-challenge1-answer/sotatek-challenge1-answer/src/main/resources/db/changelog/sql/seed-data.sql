INSERT INTO products(sku,
                     name,
                     description)
VALUES ('A100',
        'Laptop',
        'Gaming Laptop'),
       ('B200',
        'Mouse',
        'Wireless Mouse');

INSERT INTO inventory(sku,
                      total_stock,
                      available_stock,
                      reserved_stock)
VALUES ('A100',
        100,
        100,
        0),
       ('B200',
        50,
        50,
        0);