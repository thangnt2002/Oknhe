package com.sotatek.thangnt.dto.request;

import jakarta.validation.constraints.Min;
import lombok.*;
import jakarta.validation.constraints.NotBlank;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReservationItemRequest {

    @NotBlank
    private String sku;

    @Min(1)
    private Integer quantity;
}