package com.sotatek.thangnt.service;

import com.sotatek.thangnt.dto.response.InventoryResponse;

public interface InventoryService {
    InventoryResponse getBySku(String sku);

}
