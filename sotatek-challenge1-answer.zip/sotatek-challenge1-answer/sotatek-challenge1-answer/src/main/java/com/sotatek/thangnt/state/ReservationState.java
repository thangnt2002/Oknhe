package com.sotatek.thangnt.state;

import com.sotatek.thangnt.entity.Reservation;

public interface ReservationState {

    void confirm(Reservation reservation);

    void cancel(Reservation reservation);
}