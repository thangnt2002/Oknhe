package com.sotatek.thangnt.exception;

import org.springframework.http.HttpStatus;

import static com.sotatek.thangnt.enums.ErrorCode.INVENTORY_NOT_FOUND;

public class InventoryNotFoundException
        extends BusinessException {

    public InventoryNotFoundException(String sku) {
        super(
                INVENTORY_NOT_FOUND.name(),
                "Inventory not found for sku " + sku,
                HttpStatus.NOT_FOUND
        );
    }
}