package com.sotatek.thangnt.controller;

import com.sotatek.thangnt.dto.response.ApiResponse;
import com.sotatek.thangnt.dto.response.InventoryResponse;
import com.sotatek.thangnt.service.InventoryService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/inventory")
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class InventoryController {

    InventoryService inventoryService;

    @GetMapping("/{sku}")
    public ApiResponse<InventoryResponse> getInventory(@PathVariable String sku) {
        InventoryResponse response = inventoryService.getBySku(sku);
        return ApiResponse.<InventoryResponse>builder()
                .success(true)
                .data(response)
                .message("getInventory success")
                .build();
    }
}