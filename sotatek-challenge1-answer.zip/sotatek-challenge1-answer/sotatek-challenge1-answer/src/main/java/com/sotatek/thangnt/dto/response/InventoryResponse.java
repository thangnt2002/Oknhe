package com.sotatek.thangnt.dto.response;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class InventoryResponse {
    private String sku;

    private Integer totalStock;

    private Integer availableStock;

    private Integer reservedStock;
}
