package com.sotatek.thangnt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SotatekChallenge1AnswerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SotatekChallenge1AnswerApplication.class, args);
	}

}
