package com.sotatek.thangnt.exception;

import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public abstract class BusinessException
        extends RuntimeException {

    private final String code;

    private final HttpStatus status;

    protected BusinessException(
            String code,
            String message,
            HttpStatus status
    ) {

        super(message);

        this.code = code;
        this.status = status;
    }
}