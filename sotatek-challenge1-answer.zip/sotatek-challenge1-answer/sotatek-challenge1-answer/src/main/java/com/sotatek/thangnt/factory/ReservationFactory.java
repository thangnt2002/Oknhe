package com.sotatek.thangnt.factory;

import com.sotatek.thangnt.entity.Reservation;
import com.sotatek.thangnt.entity.ReservationItem;
import com.sotatek.thangnt.enums.ReservationStatus;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

@Component
public class ReservationFactory {

    public Reservation create(
            String orderId,
            List<ReservationItem> items
    ) {

        Reservation reservation = new Reservation();

        reservation.setOrderId(orderId);
        reservation.setStatus(
                ReservationStatus.PENDING
        );
        reservation.setCreatedAt(
                LocalDateTime.now()
        );
        reservation.setItems(items);

        return reservation;
    }
}