package com.sotatek.thangnt.state;

import com.sotatek.thangnt.entity.Reservation;
import com.sotatek.thangnt.exception.InvalidReservationStateException;

public class CancelledState implements ReservationState {

    @Override
    public void confirm(Reservation reservation) {
        throw new InvalidReservationStateException(
                "Cancelled reservation cannot be confirmed"
        );
    }

    @Override
    public void cancel(Reservation reservation) {
        throw new InvalidReservationStateException(
                "Reservation already cancelled"
        );
    }
}