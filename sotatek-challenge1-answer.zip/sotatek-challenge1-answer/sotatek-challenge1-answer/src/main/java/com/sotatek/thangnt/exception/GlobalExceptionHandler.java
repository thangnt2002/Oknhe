package com.sotatek.thangnt.exception;

import com.sotatek.thangnt.dto.response.ApiResponse;
import jakarta.validation.ConstraintViolationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.PessimisticLockingFailureException;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import static com.sotatek.thangnt.enums.ErrorCode.*;

@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(BusinessException.class)
    public ResponseEntity<ApiResponse<Object>> handleBusinessException(BusinessException ex) {
        return ResponseEntity.status(ex.getStatus())
                .body(ApiResponse.<Object>builder()
                        .success(false)
                        .code(ex.getCode())
                        .message(ex.getMessage())
                        .build());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiResponse<Object>> handleValidationException(MethodArgumentNotValidException ex) {

        String message = ex.getBindingResult()
                .getFieldErrors()
                .stream()
                .findFirst()
                .map(DefaultMessageSourceResolvable::getDefaultMessage)
                .orElse("Validation failed");

        return ResponseEntity.badRequest()
                .body(ApiResponse.builder()
                        .success(false)
                        .code(VALIDATION_ERROR.name())
                        .message(message)
                        .build());
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ApiResponse<Object>> handleConstraintViolation(ConstraintViolationException ex) {

        return ResponseEntity.badRequest()
                .body(ApiResponse.builder()
                        .success(false)
                        .code(VALIDATION_ERROR.name())
                        .message(ex.getMessage())
                        .build());
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ApiResponse<Object>> handleMalformedJson(HttpMessageNotReadableException ex) {

        return ResponseEntity.badRequest()
                .body(ApiResponse.builder()
                        .success(false)
                        .code(INVALID_REQUEST_BODY.name())
                        .message("Malformed JSON request")
                        .build());

    }

    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<ApiResponse<Object>> handleTypeMismatch(MethodArgumentTypeMismatchException ex) {

        return ResponseEntity.badRequest()
                .body(ApiResponse.builder()
                        .success(false)
                        .code(INVALID_PARAMETER.name())
                        .message(ex.getName() + " is invalid")
                        .build());
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<ApiResponse<Object>> handleDataIntegrityViolation(DataIntegrityViolationException ex) {

        log.error("Database constraint violation", ex);
        return ResponseEntity.badRequest()
                .body(ApiResponse.builder()
                        .success(false)
                        .code(DATA_INTEGRITY_VIOLATION.name())
                        .message("Database constraint violation")
                        .build());
    }

    @ExceptionHandler(PessimisticLockingFailureException.class)
    public ResponseEntity<ApiResponse<Object>> handlePessimisticLock(PessimisticLockingFailureException ex) {
        log.error("Database constraint violation", ex);
        return ResponseEntity.status(409)
                .body(ApiResponse.builder()
                        .success(false)
                        .code(CONCURRENT_MODIFICATION.name())
                        .message("Inventory is currently being updated")
                        .build());
    }

    @ExceptionHandler(JpaSystemException.class)
    public ResponseEntity<ApiResponse<Object>> handleJpaException(JpaSystemException ex) {

        log.error("JpaSystemException", ex);
        return ResponseEntity.internalServerError()
                .body(ApiResponse.builder()
                        .success(false)
                        .code(DATABASE_ERROR.name())
                        .message("Database error occurred")
                        .build());
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiResponse<Object>> handleException(Exception ex) {

        log.error("Unexpected exception", ex);
        return ResponseEntity.internalServerError()
                .body(ApiResponse.builder()
                        .success(false)
                        .code(INTERNAL_SERVER_ERROR.name())
                        .message("Unexpected error occurred")
                        .build());
    }
}