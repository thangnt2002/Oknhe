package com.sotatek.thangnt.exception;

import org.springframework.http.HttpStatus;

import static com.sotatek.thangnt.enums.ErrorCode.INVALID_RESERVATION_STATE;

public class InvalidReservationStateException
        extends BusinessException {

    public InvalidReservationStateException(
            String message
    ) {
        super(
                INVALID_RESERVATION_STATE.name(),
                message,
                HttpStatus.CONFLICT
        );
    }
}
