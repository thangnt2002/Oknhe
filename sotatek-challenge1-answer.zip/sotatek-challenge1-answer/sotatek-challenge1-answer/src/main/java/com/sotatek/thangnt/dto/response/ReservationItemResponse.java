package com.sotatek.thangnt.dto.response;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReservationItemResponse {

    private String sku;

    private Integer quantity;
}
