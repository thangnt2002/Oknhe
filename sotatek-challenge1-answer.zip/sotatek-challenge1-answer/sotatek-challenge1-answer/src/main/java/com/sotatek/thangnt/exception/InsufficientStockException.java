package com.sotatek.thangnt.exception;

import org.springframework.http.HttpStatus;

import static com.sotatek.thangnt.enums.ErrorCode.INSUFFICIENT_STOCK;

public class InsufficientStockException extends BusinessException {

    public InsufficientStockException(String sku, int available, int requested) {

        super(INSUFFICIENT_STOCK.name(),
                String.format("SKU %s has only %d units available," +
                        " %d were requested", sku, available, requested),
                HttpStatus.CONFLICT);
    }
}



