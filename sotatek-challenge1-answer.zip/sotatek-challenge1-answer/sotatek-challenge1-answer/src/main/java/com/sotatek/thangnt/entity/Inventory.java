package com.sotatek.thangnt.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "inventory")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Inventory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String sku;

    private Integer totalStock;

    private Integer availableStock;

    private Integer reservedStock;

    public boolean canReserve(Integer quantity) {
        return availableStock >= quantity;
    }

    public void reserve(Integer quantity) {
        availableStock -= quantity;
        reservedStock += quantity;
    }

    public void release(Integer quantity) {
        availableStock += quantity;
        reservedStock -= quantity;
    }
}