package com.sotatek.thangnt.controller;

import com.sotatek.thangnt.dto.request.CreateReservationRequest;
import com.sotatek.thangnt.dto.response.ApiResponse;
import com.sotatek.thangnt.dto.response.InventoryResponse;
import com.sotatek.thangnt.dto.response.ReservationResponse;
import com.sotatek.thangnt.service.ReservationService;
import jakarta.validation.Valid;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/reservations")
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class ReservationController {

    ReservationService reservationService;

    @PostMapping
    public ApiResponse<ReservationResponse> reserve(@Valid @RequestBody CreateReservationRequest request) {
        ReservationResponse response = reservationService.reserve(request);
        return ApiResponse.<ReservationResponse>builder()
                .success(true)
                .data(response)
                .message("reserve success")
                .build();
    }

    @PostMapping("/{id}/confirm")
    public ApiResponse<ReservationResponse> confirm(@PathVariable Long id) {
        ReservationResponse response = reservationService.confirm(id);
        return ApiResponse.<ReservationResponse>builder()
                .success(true)
                .data(response)
                .message("confirm success")
                .build();
    }

    @PostMapping("/{id}/cancel")
    public ApiResponse<ReservationResponse> cancel(@PathVariable Long id) {
        ReservationResponse response = reservationService.cancel(id);
        return ApiResponse.<ReservationResponse>builder()
                .success(true)
                .data(response)
                .message("cancel success")
                .build();
    }

    @GetMapping("/{id}")
    public ApiResponse<ReservationResponse> getById(@PathVariable Long id) {
        ReservationResponse response = reservationService.getById(id);
        return ApiResponse.<ReservationResponse>builder()
                .success(true)
                .data(response)
                .message("getById success")
                .build();
    }
}