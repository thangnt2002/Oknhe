package com.sotatek.thangnt.mapper;

import com.sotatek.thangnt.dto.response.ReservationResponse;
import com.sotatek.thangnt.entity.Reservation;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface ReservationMapper {

    @Mapping(target = "status", expression = "java(reservation.getStatus().name())")
    ReservationResponse toResponse(Reservation reservation);
}
