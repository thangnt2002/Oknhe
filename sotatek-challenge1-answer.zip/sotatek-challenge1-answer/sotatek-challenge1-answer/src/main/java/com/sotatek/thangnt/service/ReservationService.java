package com.sotatek.thangnt.service;

import com.sotatek.thangnt.dto.request.CreateReservationRequest;
import com.sotatek.thangnt.dto.response.ReservationResponse;

public interface ReservationService {
    ReservationResponse reserve(CreateReservationRequest request);
    ReservationResponse confirm(Long reservationId);
    ReservationResponse cancel(Long reservationId);
    ReservationResponse getById(Long reservationId);
}
