package com.sotatek.thangnt.state;

import com.sotatek.thangnt.entity.Reservation;
import com.sotatek.thangnt.enums.ReservationStatus;

public class PendingState implements ReservationState {

    @Override
    public void confirm(Reservation reservation) {
        reservation.setStatus(ReservationStatus.CONFIRMED);
    }

    @Override
    public void cancel(Reservation reservation) {
        reservation.setStatus(ReservationStatus.CANCELLED);
    }
}
