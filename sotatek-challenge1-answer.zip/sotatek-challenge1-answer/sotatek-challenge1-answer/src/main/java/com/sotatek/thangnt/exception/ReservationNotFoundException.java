package com.sotatek.thangnt.exception;

import org.springframework.http.HttpStatus;

import static com.sotatek.thangnt.enums.ErrorCode.RESERVATION_NOT_FOUND;

public class ReservationNotFoundException
        extends BusinessException {

    public ReservationNotFoundException(Long id) {
        super(
                RESERVATION_NOT_FOUND.name(),
                "Reservation not found with id " + id,
                HttpStatus.NOT_FOUND
        );
    }
}