package com.sotatek.thangnt.mapper;

import com.sotatek.thangnt.dto.response.InventoryResponse;
import com.sotatek.thangnt.entity.Inventory;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface InventoryMapper {

    InventoryResponse toResponse(Inventory inventory);
}
