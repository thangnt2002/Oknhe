package com.sotatek.thangnt.enums;

public enum ReservationStatus {
    PENDING,
    CONFIRMED,
    CANCELLED
}
