package com.sotatek.thangnt.factory;

import com.sotatek.thangnt.enums.ReservationStatus;
import com.sotatek.thangnt.state.CancelledState;
import com.sotatek.thangnt.state.ConfirmedState;
import com.sotatek.thangnt.state.PendingState;
import com.sotatek.thangnt.state.ReservationState;
import org.springframework.stereotype.Component;

@Component
public class ReservationStateFactory {

    public ReservationState getState(ReservationStatus status) {
        return switch (status) {
            case PENDING -> new PendingState();
            case CONFIRMED -> new ConfirmedState();
            case CANCELLED -> new CancelledState();
        };
    }
}