package com.sotatek.thangnt.dto.response;

import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReservationResponse {

    private Long id;

    private String orderId;

    private String status;

    private LocalDateTime createdAt;

    private List<ReservationItemResponse> items;
}