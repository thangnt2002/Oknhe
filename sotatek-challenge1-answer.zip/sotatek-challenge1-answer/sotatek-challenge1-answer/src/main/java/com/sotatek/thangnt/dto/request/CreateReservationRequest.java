package com.sotatek.thangnt.dto.request;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CreateReservationRequest {

    @NotBlank
    private String orderId;

    @Valid
    @NotEmpty
    private List<ReservationItemRequest> items;
}