package com.sotatek.thangnt.mapper;

import com.sotatek.thangnt.dto.response.ReservationItemResponse;
import com.sotatek.thangnt.entity.ReservationItem;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface ReservationItemMapper {

    ReservationItemResponse toResponse(ReservationItem item);
}