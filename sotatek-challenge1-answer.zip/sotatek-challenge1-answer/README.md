# Inventory Reservation System

## Overview

This project implements an Inventory Reservation System that allows clients to:

View inventory by SKU
Reserve inventory for an order
Confirm a reservation
Cancel a reservation

The system ensures inventory consistency and prevents overselling by using database locking during reservation and cancellation operations.

---

## Tech Stack

Java 17
Spring Boot 3
Spring Data JPA
PostgreSQL
Liquibase
Docker & Docker Compose
JUnit 5
Mockito
Lombok
MapStruct

---

## Architecture

The project follows Clean Architecture principles.
text
src/main/java/com/sotatek/thangnt

├── controller
│
├── dto
│   ├── request
│   └── response
│
├── entity
│
├── repository
│
├── service
│   ├── impl
│   └── state
│
├── mapper
│
├── enum
│
├── factory
│
├── exception
│
└── state

### Layers

#### Controller

Handles HTTP requests and responses.

#### Service

Contains business logic.

#### Repository

Responsible for database access.

#### Domain Entities

Contain domain behavior such as:

reserve()
release()

#### State Pattern

Reservation state transitions are implemented using the State Pattern.

Supported states:
text
PENDING
CONFIRMED
CANCELLED

Allowed transitions:
text
PENDING -> CONFIRMED
PENDING -> CANCELLED

Invalid transitions throw:
text
InvalidReservationStateException

---

## Database

PostgreSQL is used as the primary database.

Liquibase manages all schema changes using SQL files only.

### Tables

#### products
text
id
sku
name
description

#### inventory
text
id
sku
total_stock
available_stock
reserved_stock

#### reservations
text
id
order_id
status
created_at

#### reservation_items
text
id
reservation_id
sku
quantity

---

## Concurrency Control

To prevent overselling:
java
@Lock(LockModeType.PESSIMISTIC_WRITE)
Optional<Inventory> findBySkuForUpdate(String sku);

The inventory row is locked during:

reserve
cancel

This guarantees consistent stock updates.

---

## Running with Docker

### Build and Start
bash
docker compose up --build
will perform the following steps:

1. Compile source code
2. Execute all unit tests
3. Package the application
4. Build the Docker image
5. Start the application container
   text
   http://localhost:8080

PostgreSQL:
text
localhost:5432

Database:
sotatek

User:
postgres

Password:
postgres

---

## API Endpoints

### Get Inventory
http
GET /api/v1/inventory/{sku}

Example:
http
GET /api/v1/inventory/A100

Response:
json
{
"sku": "A100",
"totalStock": 100,
"availableStock": 80,
"reservedStock": 20
}

---

### Create Reservation
http
POST /api/v1/reservations

Request:
json
{
"orderId": "ORD-1001",
"items": [
{
"sku": "A100",
"quantity": 10
}
]
}

Response:
json
{
"id": 1,
"orderId": "ORD-1001",
"status": "PENDING"
}

---

### Confirm Reservation
http
POST /api/v1/reservations/1/confirm

Response:
json
{
"id": 1,
"orderId": "ORD-1001",
"status": "CONFIRMED"
}

---

### Cancel Reservation
http
POST /api/v1/reservations/1/cancel

Response:
json
{
"id": 1,
"orderId": "ORD-1001",
"status": "CANCELLED"
}

---

### Get Reservation
http
GET /api/v1/reservations/{id}

Example:
http
GET /api/v1/reservations/1

---

## Error Handling

Centralized exception handling is implemented using:
java
@RestControllerAdvice

Supported exceptions:

InventoryNotFoundException
ReservationNotFoundException
InsufficientStockException
InvalidReservationStateException
MethodArgumentNotValidException
Exception

Example response:
json
{
"status": 400,
"error": "INSUFFICIENT_STOCK",
"message": "Insufficient stock for sku A100"
}

---

## Unit Tests

Implemented using:

JUnit 5
Mockito

Coverage includes:

### Inventory Service

get inventory success
inventory not found

### Reservation Service

reserve success
inventory not found
insufficient stock

### Reservation State

pending -> confirmed
pending -> cancelled

### Invalid State Transitions

confirmed -> confirmed
confirmed -> cancelled
cancelled -> confirm
cancelled -> cancel

---

## Assumptions

1. orderId is provided by an external Order System.
2. Inventory already exists before reservation.
3. Reservation confirmation does not change stock quantities.
4. Reservation cancellation releases reserved stock.
5. Overselling is prevented through pessimistic locking.